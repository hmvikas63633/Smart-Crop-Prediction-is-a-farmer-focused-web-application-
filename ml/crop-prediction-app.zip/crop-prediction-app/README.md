# 🌾 Smart Crop Prediction System

AI-powered web application that helps farmers predict the best crop to grow based on soil and climate conditions.

## 🎯 Features

- **Easy-to-use Interface**: Farmer-friendly design with simple input forms
- **AI-Powered Predictions**: Uses Random Forest ML model trained on real agricultural data
- **Multiple Recommendations**: Shows top 3 crop suggestions with confidence scores
- **Quick Sample Data**: Pre-filled examples for testing (Rice, Wheat, Cotton)
- **Real-time Results**: Instant predictions with detailed information
- **Mobile Responsive**: Works on phones, tablets, and computers

## 📊 Input Parameters

The system analyzes 7 key factors:

1. **Nitrogen (N)** - Soil nitrogen content (kg/ha)
2. **Phosphorus (P)** - Soil phosphorus content (kg/ha)
3. **Potassium (K)** - Soil potassium content (kg/ha)
4. **Temperature** - Average temperature (°C)
5. **Humidity** - Relative humidity (%)
6. **pH** - Soil pH level (0-14)
7. **Rainfall** - Annual rainfall (mm)

## 🚀 Installation & Setup

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 2: Download Dataset

1. Go to Kaggle: https://www.kaggle.com/datasets/atharvaingle/crop-recommendation-dataset
2. Download `Crop_recommendation.csv`
3. Place the CSV file in the project directory

### Step 3: Train the Model

```bash
python train_model.py
```

This will:
- Load the dataset
- Train the Random Forest model
- Evaluate accuracy
- Save the trained model as `crop_model.pkl`

### Step 4: Run the Application

```bash
python app.py
```

### Step 5: Open in Browser

Open your web browser and go to:
```
http://localhost:5000
```

## 📱 How to Use

1. **Enter Soil Data**
   - Get your soil tested for NPK values and pH
   - Or use the sample data buttons for testing

2. **Enter Climate Data**
   - Record average temperature and humidity
   - Note annual rainfall in your area

3. **Click "Predict Best Crop"**
   - The AI will analyze your data
   - Get instant recommendations

4. **View Results**
   - See top 3 recommended crops
   - Check confidence scores
   - Read crop descriptions

## 🌱 Supported Crops

The model can recommend from 22 different crops:

- **Cereals**: Rice, Maize, Wheat
- **Pulses**: Chickpea, Kidney beans, Pigeon peas, Moth beans, Mung bean, Black gram, Lentil
- **Fruits**: Banana, Mango, Grapes, Watermelon, Muskmelon, Apple, Orange, Papaya, Pomegranate, Coconut
- **Commercial**: Cotton, Jute, Coffee

## 🔧 Technical Details

### Backend (Flask API)

- **Framework**: Flask 3.0.0
- **ML Model**: Random Forest Classifier (scikit-learn)
- **API Endpoints**:
  - `POST /api/predict` - Get crop predictions
  - `GET /api/model-info` - Get model information

### Frontend

- **HTML5 + CSS3 + Vanilla JavaScript**
- **Responsive Design**: Works on all devices
- **No external dependencies**: Pure CSS styling
- **Gradient backgrounds** for modern look

### Machine Learning

- **Algorithm**: Random Forest Classifier
- **Features**: 7 (N, P, K, Temperature, Humidity, pH, Rainfall)
- **Training Data**: Kaggle Crop Recommendation Dataset
- **Accuracy**: ~99% on test data

## 📂 Project Structure

```
crop-prediction-app/
│
├── app.py                  # Flask backend server
├── train_model.py          # Model training script
├── requirements.txt        # Python dependencies
├── crop_model.pkl         # Trained ML model (generated)
│
├── static/
│   └── index.html         # Frontend UI
│
└── README.md              # This file
```

## 🎨 Sample Data for Testing

### Rice Sample
- Nitrogen: 90 kg/ha
- Phosphorus: 42 kg/ha
- Potassium: 43 kg/ha
- Temperature: 20.8°C
- Humidity: 82%
- pH: 6.5
- Rainfall: 202.9 mm

### Wheat Sample
- Nitrogen: 80 kg/ha
- Phosphorus: 40 kg/ha
- Potassium: 40 kg/ha
- Temperature: 20°C
- Humidity: 70%
- pH: 6.5
- Rainfall: 150 mm

### Cotton Sample
- Nitrogen: 120 kg/ha
- Phosphorus: 60 kg/ha
- Potassium: 40 kg/ha
- Temperature: 25°C
- Humidity: 50%
- pH: 7.0
- Rainfall: 100 mm

## 🐛 Troubleshooting

### Model not found error
- Make sure to run `python train_model.py` first
- Check if `crop_model.pkl` exists in the directory

### Cannot connect to server
- Ensure Flask app is running (`python app.py`)
- Check if port 5000 is not blocked by firewall
- Verify the API_URL in index.html matches your server

### CORS errors
- The app uses Flask-CORS to handle cross-origin requests
- If issues persist, check browser console for details

## 🤝 Contributing

Contributions are welcome! Feel free to:
- Report bugs
- Suggest new features
- Improve documentation
- Add more crops to the database

## 📄 License

This project is open source and available for educational purposes.

## 🙏 Acknowledgments

- Dataset: [Kaggle Crop Recommendation Dataset](https://www.kaggle.com/datasets/atharvaingle/crop-recommendation-dataset)
- ML Framework: scikit-learn
- Web Framework: Flask

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review the code comments
3. Test with sample data first

---

**Made with ❤️ for farmers and agriculture enthusiasts**

🌾 Happy Farming! 🌾
