from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
import joblib
import os

app = Flask(__name__, static_folder='static')
CORS(app)

# Global variable to store the model
model = None
crop_info = {
    'rice': {'emoji': '🌾', 'description': 'Rice grows well in flooded conditions with high humidity'},
    'maize': {'emoji': '🌽', 'description': 'Maize requires moderate rainfall and warm temperatures'},
    'chickpea': {'emoji': '🫘', 'description': 'Chickpea is drought-resistant and grows in cooler climates'},
    'kidneybeans': {'emoji': '🫘', 'description': 'Kidney beans need moderate water and warm weather'},
    'pigeonpeas': {'emoji': '🫛', 'description': 'Pigeon peas are drought-tolerant legumes'},
    'mothbeans': {'emoji': '🫘', 'description': 'Moth beans thrive in dry, hot conditions'},
    'mungbean': {'emoji': '🫛', 'description': 'Mung beans need warm temperatures and moderate rainfall'},
    'blackgram': {'emoji': '🫘', 'description': 'Black gram grows well in tropical and subtropical areas'},
    'lentil': {'emoji': '🫘', 'description': 'Lentils prefer cool weather and moderate rainfall'},
    'pomegranate': {'emoji': '🍎', 'description': 'Pomegranate thrives in hot, dry climates'},
    'banana': {'emoji': '🍌', 'description': 'Banana requires high humidity and rainfall'},
    'mango': {'emoji': '🥭', 'description': 'Mango grows best in tropical climates'},
    'grapes': {'emoji': '🍇', 'description': 'Grapes need moderate temperatures and well-drained soil'},
    'watermelon': {'emoji': '🍉', 'description': 'Watermelon requires warm weather and sandy soil'},
    'muskmelon': {'emoji': '🍈', 'description': 'Muskmelon grows well in hot, dry climates'},
    'apple': {'emoji': '🍎', 'description': 'Apple trees need cool winters and moderate summers'},
    'orange': {'emoji': '🍊', 'description': 'Orange trees thrive in subtropical climates'},
    'papaya': {'emoji': '🥭', 'description': 'Papaya requires warm temperatures year-round'},
    'coconut': {'emoji': '🥥', 'description': 'Coconut palms need coastal, tropical conditions'},
    'cotton': {'emoji': '☁️', 'description': 'Cotton requires hot weather and moderate rainfall'},
    'jute': {'emoji': '🌿', 'description': 'Jute grows in warm, humid climates with heavy rainfall'},
    'coffee': {'emoji': '☕', 'description': 'Coffee needs shade, altitude, and consistent rainfall'}
}

def load_or_train_model():
    """Load existing model or train a new one"""
    global model
    
    model_path = 'crop_model.pkl'
    
    # Check if model exists
    if os.path.exists(model_path):
        print("Loading existing model...")
        model = joblib.load(model_path)
        return
    
    # Train new model (using sample data structure)
    # In production, you would load the actual dataset
    print("Training new model...")
    
    # Sample training data (replace with actual dataset)
    # This is just for demonstration - in production, load from CSV
    sample_data = {
        'N': [90, 85, 40, 80, 20, 10, 20, 40, 70, 50],
        'P': [42, 58, 67, 40, 80, 80, 67, 60, 60, 40],
        'K': [43, 41, 20, 20, 9, 10, 20, 30, 30, 20],
        'temperature': [20.8, 21.7, 27.0, 20.0, 25.0, 26.0, 24.0, 23.0, 22.0, 21.0],
        'humidity': [82.0, 80.3, 51.0, 82.0, 30.0, 20.0, 45.0, 60.0, 70.0, 75.0],
        'ph': [6.5, 7.0, 6.0, 7.5, 6.0, 5.5, 6.5, 7.0, 6.8, 6.2],
        'rainfall': [202.9, 226.7, 103.0, 200.0, 50.0, 30.0, 80.0, 120.0, 150.0, 140.0],
        'label': ['rice', 'rice', 'chickpea', 'rice', 'cotton', 'pomegranate', 'cotton', 'lentil', 'maize', 'banana']
    }
    
    df = pd.DataFrame(sample_data)
    X = df.drop('label', axis=1)
    y = df['label']
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, y)
    
    # Save the model
    joblib.dump(model, model_path)
    print("Model trained and saved!")

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        
        # Extract features
        N = float(data.get('nitrogen', 0))
        P = float(data.get('phosphorus', 0))
        K = float(data.get('potassium', 0))
        temperature = float(data.get('temperature', 0))
        humidity = float(data.get('humidity', 0))
        ph = float(data.get('ph', 0))
        rainfall = float(data.get('rainfall', 0))
        
        # Validate inputs
        if any(v < 0 for v in [N, P, K, temperature, humidity, ph, rainfall]):
            return jsonify({'error': 'All values must be positive'}), 400
        
        # Make prediction
        input_data = [[N, P, K, temperature, humidity, ph, rainfall]]
        prediction = model.predict(input_data)[0]
        
        # Get probabilities for top 3 crops
        probabilities = model.predict_proba(input_data)[0]
        top_3_indices = np.argsort(probabilities)[-3:][::-1]
        
        recommendations = []
        for idx in top_3_indices:
            crop_name = model.classes_[idx]
            confidence = float(probabilities[idx] * 100)
            
            crop_data = crop_info.get(crop_name.lower(), {'emoji': '🌱', 'description': 'Good crop choice'})
            
            recommendations.append({
                'crop': crop_name,
                'confidence': round(confidence, 2),
                'emoji': crop_data['emoji'],
                'description': crop_data['description']
            })
        
        return jsonify({
            'success': True,
            'primary_crop': prediction,
            'recommendations': recommendations,
            'input_data': {
                'N': N, 'P': P, 'K': K,
                'temperature': temperature,
                'humidity': humidity,
                'ph': ph,
                'rainfall': rainfall
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/model-info', methods=['GET'])
def model_info():
    """Get information about the model"""
    try:
        return jsonify({
            'success': True,
            'model_type': 'Random Forest Classifier',
            'features': ['Nitrogen (N)', 'Phosphorus (P)', 'Potassium (K)', 
                        'Temperature (°C)', 'Humidity (%)', 'pH', 'Rainfall (mm)'],
            'total_crops': len(model.classes_) if model else 0,
            'crops': list(model.classes_) if model else []
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Load or train the model
    load_or_train_model()
    
    # Run the app
    app.run(debug=True, host='0.0.0.0', port=5000)
