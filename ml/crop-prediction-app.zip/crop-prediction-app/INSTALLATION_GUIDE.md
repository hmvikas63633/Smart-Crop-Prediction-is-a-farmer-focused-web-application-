# 💻 INSTALLATION GUIDE - Step by Step

## Where Can I Install This?

You can install this application on:
- ✅ Windows PC/Laptop
- ✅ Mac Computer
- ✅ Linux Computer
- ✅ Even Raspberry Pi for field use!

## 🎯 Complete Installation Steps

### STEP 1: Download the Application Files

**Option A: If you have the files already**
1. You should have a folder called `crop-prediction-app`
2. This folder contains all the files you need

**Option B: Download from where you received them**
1. Download the complete `crop-prediction-app` folder
2. Save it somewhere easy to find (like Desktop or Documents)

### STEP 2: Install Python

**For Windows:**
1. Go to: https://www.python.org/downloads/
2. Click the big yellow button "Download Python 3.12.x"
3. Run the downloaded installer
4. ⚠️ **IMPORTANT**: Check the box "Add Python to PATH"
5. Click "Install Now"
6. Wait for installation to complete

**For Mac:**
1. Go to: https://www.python.org/downloads/
2. Download Python for macOS
3. Open the downloaded .pkg file
4. Follow the installation wizard

**For Linux (Ubuntu/Debian):**
Open Terminal and type:
```bash
sudo apt update
sudo apt install python3 python3-pip
```

### STEP 3: Open Command Prompt/Terminal

**On Windows:**
1. Press `Windows Key + R`
2. Type `cmd` and press Enter
OR
1. Click Start Menu
2. Type "Command Prompt"
3. Click on Command Prompt

**On Mac:**
1. Press `Command + Space`
2. Type "Terminal"
3. Press Enter

**On Linux:**
1. Press `Ctrl + Alt + T`

### STEP 4: Navigate to the Application Folder

In the Command Prompt/Terminal, type:

**If you saved on Desktop:**
```bash
cd Desktop/crop-prediction-app
```

**If you saved in Documents:**
```bash
cd Documents/crop-prediction-app
```

**If you saved somewhere else:**
```bash
cd path/to/crop-prediction-app
```

💡 **Tip**: You can drag the folder into the terminal window to auto-fill the path!

### STEP 5: Install Required Software

Type this command and press Enter:

```bash
pip install -r requirements.txt
```

**What this does:**
- Installs Flask (web server)
- Installs scikit-learn (AI/ML library)
- Installs pandas (data processing)
- Installs other needed libraries

⏱️ **Wait 2-5 minutes** for installation to complete.

### STEP 6: Download the Training Dataset

1. Open your web browser
2. Go to: https://www.kaggle.com/datasets/atharvaingle/crop-recommendation-dataset
3. You may need to create a free Kaggle account (it's free!)
4. Click the "Download" button
5. You'll get a file called: `Crop_recommendation.csv` or `archive.zip`
6. If it's a zip file, extract it
7. Copy `Crop_recommendation.csv` into your `crop-prediction-app` folder

**The file should be here:**
```
crop-prediction-app/
  ├── app.py
  ├── train_model.py
  ├── Crop_recommendation.csv  ← This file
  └── ...
```

### STEP 7: Train the AI Model

In Command Prompt/Terminal (still in the crop-prediction-app folder), type:

```bash
python train_model.py
```

**What you'll see:**
```
==================================================
CROP PREDICTION MODEL TRAINING
==================================================

1. Loading dataset...
   ✅ Dataset loaded successfully!
   
2. Dataset Information...
   
3. Preparing data...
   
4. Training Random Forest...
   ✅ Model trained successfully!
   
5. Evaluating model...
   🎯 Accuracy: 99.54%
   
...

✅ MODEL TRAINING COMPLETED SUCCESSFULLY!
==================================================
```

⏱️ **This takes 30 seconds to 2 minutes**

### STEP 8: Start the Application

Type this command:

```bash
python app.py
```

**What you'll see:**
```
 * Running on http://127.0.0.1:5000
 * Running on http://192.168.x.x:5000
```

✅ **The app is now running!**

⚠️ **Keep this window open** - Don't close Command Prompt/Terminal

### STEP 9: Open in Your Browser

1. Open any web browser (Chrome, Firefox, Safari, Edge)
2. Type in the address bar:
```
http://localhost:5000
```
3. Press Enter

🎉 **You should see the Crop Prediction System!**

---

## 📱 Accessing from Other Devices (Phone/Tablet)

If you want to use the app on your phone while it runs on your computer:

### Step 1: Find Your Computer's IP Address

**On Windows:**
1. Open Command Prompt
2. Type: `ipconfig`
3. Look for "IPv4 Address" - something like `192.168.1.100`

**On Mac/Linux:**
1. Open Terminal
2. Type: `ifconfig` (Mac) or `ip addr` (Linux)
3. Look for IP address like `192.168.1.100`

### Step 2: Connect from Phone

1. Make sure phone is on the **same WiFi** as computer
2. Open browser on phone
3. Type: `http://YOUR_IP_ADDRESS:5000`
   - Example: `http://192.168.1.100:5000`

---

## 🎯 Quick Video Tutorial (What to Do)

Here's what each step looks like:

### 1️⃣ Download Files
```
[Download] → [Extract] → [Save to Desktop]
```

### 2️⃣ Install Python
```
[Visit python.org] → [Download] → [Install] → [✓ Add to PATH]
```

### 3️⃣ Open Terminal
```
Windows: Win+R → cmd → Enter
Mac: Cmd+Space → Terminal → Enter
```

### 4️⃣ Navigate & Install
```
cd Desktop/crop-prediction-app
pip install -r requirements.txt
```

### 5️⃣ Get Dataset
```
[Kaggle.com] → [Download CSV] → [Copy to folder]
```

### 6️⃣ Train & Run
```
python train_model.py
python app.py
```

### 7️⃣ Open Browser
```
http://localhost:5000
```

---

## ❓ Troubleshooting Common Issues

### "Python is not recognized"
**Problem**: Python not installed or not in PATH
**Solution**: 
1. Reinstall Python
2. Make sure to check "Add Python to PATH"
3. Restart Command Prompt

### "pip is not recognized"
**Solution**: 
```bash
python -m pip install -r requirements.txt
```

### "No module named flask"
**Solution**:
```bash
pip install flask flask-cors pandas scikit-learn
```

### "Cannot find Crop_recommendation.csv"
**Solution**:
1. Make sure CSV file is in the same folder as app.py
2. Check the file name is exactly: `Crop_recommendation.csv`

### Port 5000 already in use
**Solution**:
Edit app.py, change the last line to:
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```
Then use: http://localhost:5001

---

## 🔄 How to Use It Again Later

**Every time you want to use the app:**

1. Open Command Prompt/Terminal
2. Navigate to folder: `cd path/to/crop-prediction-app`
3. Run: `python app.py`
4. Open browser: `http://localhost:5000`

**To stop the app:**
- Press `Ctrl + C` in the Command Prompt/Terminal

---

## 💾 System Requirements

**Minimum:**
- Windows 7/Mac OS X 10.9/Ubuntu 18.04 or newer
- 2 GB RAM
- 500 MB free disk space
- Internet (only for initial setup)

**Recommended:**
- Windows 10/Mac OS 11/Ubuntu 20.04 or newer
- 4 GB RAM
- 1 GB free disk space

---

## 📞 Need More Help?

**Check if Python is installed:**
```bash
python --version
```
Should show: Python 3.8 or higher

**Check if pip is installed:**
```bash
pip --version
```

**List installed packages:**
```bash
pip list
```

---

## ✅ Installation Checklist

Before running the app, make sure:

- [ ] Python 3.8+ is installed
- [ ] You're in the crop-prediction-app folder
- [ ] requirements.txt packages are installed
- [ ] Crop_recommendation.csv is in the folder
- [ ] Model is trained (crop_model.pkl exists)
- [ ] App is running (python app.py)
- [ ] Browser is open at localhost:5000

---

**🎉 Congratulations! You're ready to start predicting crops!**

Remember: Keep the Command Prompt/Terminal window open while using the app!
