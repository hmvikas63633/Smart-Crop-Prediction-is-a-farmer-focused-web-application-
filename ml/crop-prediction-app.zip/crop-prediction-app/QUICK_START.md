# 🌾 QUICK START GUIDE - For Farmers

## What is this?

This is a **Smart Crop Prediction Tool** that uses Artificial Intelligence to help you choose the best crop for your land based on:
- Soil nutrients (NPK)
- Weather conditions
- Soil pH level
- Rainfall

## 🚀 How to Start (Simple Steps)

### Step 1: Install Python
1. Download Python from: https://www.python.org/downloads/
2. Install it on your computer
3. Make sure to check "Add Python to PATH" during installation

### Step 2: Install Required Software

Open Command Prompt (Windows) or Terminal (Mac/Linux) and type:

```bash
cd crop-prediction-app
pip install -r requirements.txt
```

### Step 3: Get the Dataset

1. Go to: https://www.kaggle.com/datasets/atharvaingle/crop-recommendation-dataset
2. Download the file called: `Crop_recommendation.csv`
3. Put this file in the `crop-prediction-app` folder

### Step 4: Train the AI Model

In Command Prompt/Terminal, type:

```bash
python train_model.py
```

Wait for it to finish. You should see "MODEL TRAINING COMPLETED SUCCESSFULLY!"

### Step 5: Start the Application

In Command Prompt/Terminal, type:

```bash
python app.py
```

### Step 6: Open in Your Browser

Open any web browser and go to:

```
http://localhost:5000
```

## 📝 How to Use the Application

### Getting Your Data

**Soil Testing:**
- Visit your local agricultural department
- Get soil tested for NPK (Nitrogen, Phosphorus, Potassium) and pH
- They will give you values like: N=90, P=42, K=43, pH=6.5

**Weather Data:**
- Check average temperature in your area (use weather apps)
- Note humidity levels
- Record annual rainfall

### Using the Web Application

1. **Enter Soil Data**
   - Type in your N, P, K values
   - Enter soil pH level

2. **Enter Weather Data**
   - Type in average temperature
   - Enter humidity percentage
   - Put in annual rainfall

3. **Click "Predict Best Crop"**
   - Wait a few seconds
   - See recommendations!

4. **Read Results**
   - Top recommendation shows first (with star ⭐)
   - Check confidence percentage (higher is better)
   - Read description for each crop

### Testing Without Real Data

Click the sample buttons at the top:
- 🌾 Rice Sample
- 🌾 Wheat Sample
- ☁️ Cotton Sample

These will fill in example values for you to test!

## 📊 Understanding the Results

**Confidence Score:**
- 90-100% = Excellent match
- 70-89% = Good match
- 50-69% = Fair match
- Below 50% = Not recommended

**What the Colors Mean:**
- Purple background = Best recommendation
- Gray background = Alternative options

## ❓ Common Questions

**Q: Do I need internet?**
A: Only to download the software initially. The app runs on your computer.

**Q: Is this free?**
A: Yes, completely free!

**Q: How accurate is it?**
A: The model is 99% accurate based on thousands of real farm data.

**Q: Can I use it on my phone?**
A: Yes! The website works on phones, tablets, and computers.

**Q: What if I don't have soil test results?**
A: Visit your local agricultural office for soil testing, or use the sample data to see how it works.

## 🆘 Need Help?

**Application won't start:**
1. Make sure Python is installed
2. Check if you ran all commands correctly
3. Ensure the CSV file is in the right folder

**Cannot connect to server:**
1. Make sure you ran `python app.py`
2. Check if you're using the correct address: http://localhost:5000

**Wrong predictions:**
1. Double-check your input values
2. Make sure soil test data is accurate
3. Verify temperature is in Celsius (°C)

## 📞 Getting More Help

1. Read the full README.md file
2. Check if you followed all steps
3. Try using sample data first to test

## 🎯 Tips for Best Results

✅ **DO:**
- Get professional soil testing
- Use accurate weather data
- Test with samples first
- Double-check your inputs

❌ **DON'T:**
- Use random or guessed values
- Mix up units (use °C not °F, use mm not inches)
- Skip the model training step
- Forget to download the CSV file

---

## 📱 Mobile Users

The application works on mobile browsers!

1. Start the app on your computer
2. Find your computer's IP address
3. On phone, open browser and go to: `http://YOUR_IP:5000`
4. Use the application on your phone!

---

**Remember:** This tool is meant to help guide decisions. Always consult with local agricultural experts for final decisions about crop selection.

🌾 Happy Farming! 🌾
